package fi.haagahelia.homeworkweek1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Homeworkweek1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
