package fi.haagahelia.homeworkweek1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Homeworkweek1Application {

    public static void main(String[] args) {
        SpringApplication.run(Homeworkweek1Application.class, args);
    }
}