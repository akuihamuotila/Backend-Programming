package fi.haagahelia.bookstore;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import fi.haagahelia.bookstore.domain.Book;
import fi.haagahelia.bookstore.domain.BookRepository;
import fi.haagahelia.bookstore.domain.Category;
import fi.haagahelia.bookstore.domain.CategoryRepository;
import fi.haagahelia.bookstore.domain.User;
import fi.haagahelia.bookstore.domain.UserRepository;

@SpringBootApplication
public class BookstoreApplication {

    public static void main(String[] args) {
        SpringApplication.run(BookstoreApplication.class, args);
    }

    @Bean
    public CommandLineRunner demo(BookRepository bookRepository, CategoryRepository categoryRepository, UserRepository userRepository) {
        return (args) -> {
            // Lisätään kategoriat vain kerran
            if (categoryRepository.count() == 0) {
                categoryRepository.save(new Category("Scifi"));
                categoryRepository.save(new Category("Fantasy"));
                categoryRepository.save(new Category("Satire"));
            }

            // Lisätään kirjat vain kerran
            if (bookRepository.count() == 0) {
                bookRepository.save(new Book("Dune", "Frank Herbert", 1965, categoryRepository.findByName("Scifi").orElse(null)));
                bookRepository.save(new Book("The Silmarillion", "J.R.R. Tolkien", 1977, categoryRepository.findByName("Fantasy").orElse(null)));
                bookRepository.save(new Book("Animal Farm", "George Orwell", 1945, categoryRepository.findByName("Satire").orElse(null)));
            }

            // Lisätään käyttäjät vain kerran
            if (userRepository.findByKäyttäjätunnus("user").isEmpty()) {
                userRepository.save(new User("user", new BCryptPasswordEncoder().encode("user123"), "USER"));
            }
            if (userRepository.findByKäyttäjätunnus("admin").isEmpty()) {
                userRepository.save(new User("admin", new BCryptPasswordEncoder().encode("admin123"), "ADMIN"));
            }
        };
    }
}